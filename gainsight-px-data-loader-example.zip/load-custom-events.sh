!/bin/bash
#gainsight-px-data-loader [--insertMissing] [--verbose] [--dryRun] [-n startRow] [-l lastRow] config.json [USER|ACCOUNT|CUSTOM_EVENT] input.csv
# Data type (second argument) should either be USER, ACCOUNT or CUSTOM_EVENT
# If insertMissing is specified, will insert missing records. Default behavior is to update records that are found
insertMissing does not apply to custom events, events are always inserted
# If verbose is specified, each operation is logged to stdout
# If dryRun is specified, no data is changed, inputs are parsed
# The -n and -l flags can be used to only process a portion of the file. For instance, -n 7 would start the processing on the seventh line of the file.

echo "updating user events:"
./gainsight-px-data-loader  --verbose config.json CUSTOM_EVENT custom-events.csv

